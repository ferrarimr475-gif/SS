
# GitHub Pages Deployment

1. ارفع جميع الملفات إلى Repository جديد على GitHub.
2. اذهب إلى:
   Settings → Pages
3. اختر:
   Branch: main
   Folder: /(root)
4. اضغط Save.
5. سيظهر لك رابط الموقع بعد دقيقة تقريباً.

